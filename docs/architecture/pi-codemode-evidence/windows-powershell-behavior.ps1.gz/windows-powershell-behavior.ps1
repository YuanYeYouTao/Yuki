$ErrorActionPreference = 'Stop'
$Source = '/Users/huangjiawei/.codex/worktrees/d0aa/Yuki/deploy/windows/Deploy-Yuki.ps1'
$Tokens = $null
$Errors = $null
$Ast = [System.Management.Automation.Language.Parser]::ParseFile($Source, [ref]$Tokens, [ref]$Errors)
if ($Errors.Count -ne 0) { throw 'PowerShell parser errors.' }
$PSNativeCommandArgumentPassing = 'Legacy'
$Functions = $Ast.FindAll({param($Node) $Node -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $Node.Name -in @('Save-State', 'Copy-VerifiedPayload', 'ConvertTo-NativeArgument', 'Invoke-Checked', 'Test-WslCoreVersion')}, $true)
foreach ($Function in $Functions) { Invoke-Expression $Function.Extent.Text }
$TemporaryRoot = Join-Path ([IO.Path]::GetTempPath()) ('yuki-powershell-behavior-' + [Guid]::NewGuid().ToString('N'))
$Utf8 = New-Object System.Text.UTF8Encoding($false)
try {
    $InputRoot = Join-Path $TemporaryRoot 'input'
    $OutputRoot = Join-Path $TemporaryRoot 'output'
    New-Item -ItemType Directory $InputRoot -Force | Out-Null
    [IO.File]::WriteAllText((Join-Path $InputRoot 'a.txt'), 'first', $Utf8)
    [IO.File]::WriteAllText((Join-Path $InputRoot 'b.txt'), 'second', $Utf8)
    $Manifest = [pscustomobject]@{ files = [pscustomobject]@{ 'a.txt' = 'fixture'; 'b.txt' = 'fixture' } }
    [IO.File]::WriteAllText((Join-Path $InputRoot 'manifest.json'), ($Manifest | ConvertTo-Json), $Utf8)
    $StatePath = Join-Path $TemporaryRoot 'state.json'
    Save-State ([pscustomobject]@{ step = 1 })
    Save-State ([pscustomobject]@{ step = 2 })
    if ((Get-Content -Raw $StatePath | ConvertFrom-Json).step -ne 2) { throw 'State retry failed.' }
    function Copy-Item([string]$LiteralPath, [string]$Destination) {
        if ([IO.Path]::GetFileName($LiteralPath) -eq 'b.txt') { throw 'simulated interrupted copy' }
        Microsoft.PowerShell.Management\Copy-Item -LiteralPath $LiteralPath -Destination $Destination
    }
    $Failed = $false
    try { Copy-VerifiedPayload $InputRoot $OutputRoot $Manifest } catch { $Failed = $true }
    if (-not $Failed) { throw 'Interrupted copy did not stop.' }
    Remove-Item Function:\Copy-Item
    Copy-VerifiedPayload $InputRoot $OutputRoot $Manifest
    Copy-VerifiedPayload $InputRoot $OutputRoot $Manifest
    if ((Get-ChildItem -Recurse $OutputRoot -File).Count -ne 3) { throw 'Retry left temporary files.' }
    [IO.File]::WriteAllText((Join-Path $OutputRoot 'b.txt'), 'user edit', $Utf8)
    $Failed = $false
    try { Copy-VerifiedPayload $InputRoot $OutputRoot $Manifest } catch { $Failed = $true }
    if (-not $Failed -or (Get-Content -Raw (Join-Path $OutputRoot 'b.txt')) -ne 'user edit') { throw 'Edited payload was replaced.' }
    $ArgvScript = Join-Path $TemporaryRoot 'argv.py'
    $ArgvOutput = Join-Path $TemporaryRoot 'arguments.json'
    [IO.File]::WriteAllText($ArgvScript, 'import json,sys; open(sys.argv[1], "w").write(json.dumps(sys.argv[2:], ensure_ascii=False))', $Utf8)
    $Values = @('space value', 'literal "quotes"', 'trailing\', '', '中文路径', '$1 & ;', 'slash\"quoted', 'double\\"quoted')
    Invoke-Checked '/usr/bin/python3' (@($ArgvScript, $ArgvOutput) + $Values)
    $Actual = @(Get-Content -Raw $ArgvOutput -Encoding UTF8 | ConvertFrom-Json)
    if ($Actual.Count -ne $Values.Count) { throw 'Native argument count mismatch.' }
    for ($Index = 0; $Index -lt $Values.Count; $Index++) {
        if ($Actual[$Index] -cne $Values[$Index]) { throw "Native argument mismatch at $Index." }
    }
    $BashOutput = Join-Path $TemporaryRoot 'bash space.txt'
    Invoke-Checked '/bin/bash' @('-c', 'printf "%s\n" "$1" > "$2"', 'bash', 'literal "$1" value', $BashOutput)
    if ((Get-Content -Raw $BashOutput).TrimEnd("`n") -cne 'literal "$1" value') { throw 'Bash embedded quotes were lost.' }
    $Wsl = '/usr/bin/true'
    if (-not (Test-WslCoreVersion)) { throw 'Modern WSL version result rejected.' }
    $Wsl = '/usr/bin/false'
    if (Test-WslCoreVersion) { throw 'Unsupported WSL version result accepted.' }
    $Wsl = '/missing-wsl-fixture'
    if (Test-WslCoreVersion) { throw 'Missing WSL version query accepted.' }
    function Failed-Wsl { throw 'redirected inbox WSL error fixture' }
    $Wsl = 'Failed-Wsl'
    if (Test-WslCoreVersion) { throw 'Inbox WSL native error accepted.' }
    $Rejected = $false
    try { Invoke-Checked '/usr/bin/false' @() } catch { $Rejected = $true }
    if (-not $Rejected) { throw 'Failed native command was ignored.' }
    'PowerShell parser, state, interrupted copy, preserved edits, native arguments, bash quoting and WSL version fallback passed.'

} finally {
    if (Test-Path -LiteralPath $TemporaryRoot) { Remove-Item -LiteralPath $TemporaryRoot -Recurse }
}
